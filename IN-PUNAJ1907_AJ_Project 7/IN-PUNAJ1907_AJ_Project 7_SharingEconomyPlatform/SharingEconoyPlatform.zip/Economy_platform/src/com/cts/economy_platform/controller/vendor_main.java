package com.cts.economy_platform.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.economy_platform.util.dataconn;

import com.cts.economy_platform.dao.V_Service;
import com.cts.economy_platform.bean.VendorInfo;
import com.cts.economy_platform.bean.Vendordetails;

public class vendor_main extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession hs=request.getSession();
		VendorInfo user=(VendorInfo)hs.getAttribute("user");
		String v_uid=user.getVendor_UserId();
		
		
		
		try {
	
			 Vendordetails vd = V_Service.checkven(v_uid);
			 
    
			 if(vd!=null)
		        {
		        	
		       	 hs.setAttribute("vd", vd);
		      
		       	 
		       	 
		        	RequestDispatcher rd = request.getRequestDispatcher("vendor_main1.jsp?msg3=Successfully logged in");
		        	rd.forward(request, response);
		        	
		        }
		        else
		        {
		        	RequestDispatcher rd = request.getRequestDispatcher("vendor_main.jsp?errmsg3=INVALID USER...!!!!!!!!!!!");
		            rd.forward(request, response);
		        }
		        }catch(Exception ex)
		        {
		        	RequestDispatcher rd = request.getRequestDispatcher("Exception_page.jsp");
		            rd.forward(request, response);
		        	
		        }
		        
				
			}
		
	

	
}






