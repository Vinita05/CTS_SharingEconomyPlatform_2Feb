package com.cts.economy_platform.bean;

import java.io.Serializable;

public class Service implements Serializable  {


	private int price;
	private String type1,type2,description,vendor_id,product_id;
	
	
	
	public Service(String product_id, int price, String vendor_id, String type1,String type2,String description) {
		super();
		this.product_id = product_id;
		this.price = price;
		this.vendor_id = vendor_id;
		this.type1 = type1;
		this.type2 = type2;
		
		this.description = description;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getVendor_id() {
		return vendor_id;
	}
	public void setVendor_id(String vendor_id) {
		this.vendor_id = vendor_id;
	}
	public String getType1() {
		return type1;
	}
	public void setType1(String type1) {
		this.type1 = type1;
	}
	public String getType2() {
		return type2;
	}
	public void setType2(String type2) {
		this.type2 = type2;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

	
}