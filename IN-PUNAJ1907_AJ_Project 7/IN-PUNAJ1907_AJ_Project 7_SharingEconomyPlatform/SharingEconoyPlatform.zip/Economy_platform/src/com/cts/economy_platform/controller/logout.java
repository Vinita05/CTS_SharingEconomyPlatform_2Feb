package com.cts.economy_platform.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
* Servlet implementation class logout
*/
@WebServlet("/views/logout")
public class logout extends HttpServlet {
        private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public logout() {
        super();
        // TODO Auto-generated constructor stub
    }

        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                // TODO Auto-generated method stub
                               doGet(request, response);

          
                           }
        
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
        {
            response.setContentType("text/html");  
            PrintWriter out=response.getWriter();  
              
            
              
            HttpSession session=request.getSession();  
           
            response.setHeader("Pragme", "no-cache");
            response.setHeader("Cache-Control", "no-store");
            response.setHeader("Expires", "0");
            response.setDateHeader("Expires", -1);
            session.invalidate();  
            
              
            
            request.getRequestDispatcher("index.jsp").include(request, response);  
            //out.print("You are successfully logged out!");  
            out.close();  
            
            
               
        }
                  
        }
