package com.cts.economy_platform.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.economy_platform.util.dataconn;


@WebServlet("/Update.do")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Update() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		HttpSession hts=request.getSession();
		Connection con = dataconn.connect();
		PreparedStatement ps = null;
		String id=(String) request.getParameter("Product_UserId");
		String vid=(String) request.getParameter("Vendor_UserId");
		int b=Integer.parseInt(request.getParameter("b"));
		int l=Integer.parseInt(request.getParameter("l"));
		int h=Integer.parseInt(request.getParameter("h"));
		int price=Integer.parseInt(request.getParameter("price"));
		String t2=(String) request.getParameter("t2");
		String brand=(String) request.getParameter("brand");
		String color=(String) request.getParameter("color");
		String material=(String) request.getParameter("material");
		String des=(String) request.getParameter("des");



		String query1 = "update Product_details set type2=?,length=?,breadth=?,height=?,color=?,material=?,brand=?,price=?,description=? where product_id=?" ;
        try {
			ps=con.prepareStatement(query1);
	
			ps.setString(1,t2);
			ps.setInt(2, l);
			ps.setInt(3, b);
			ps.setInt(4, h);
			ps.setString(5,color);
			ps.setString(6,material);
			ps.setString(7,brand);
			ps.setInt(8,price);
			ps.setString(9,des);
			ps.setString(10,id);
	
	
	
			ps.executeUpdate();
			
			
			RequestDispatcher rd = request.getRequestDispatcher("vendor_main.jsp?up=Your Details are Updated!!!");
            rd.forward(request, response);
		} catch (SQLException e) {
			RequestDispatcher rd = request.getRequestDispatcher("Exception_page.jsp");
            rd.forward(request, response);
		}
		
	}

}
